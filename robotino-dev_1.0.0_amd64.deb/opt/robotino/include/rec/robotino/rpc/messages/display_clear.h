#ifndef _REC_ROBOTINO_RPC_DISPLAY_CLEAR_H_
#define _REC_ROBOTINO_RPC_DISPLAY_CLEAR_H_

#include "rec/rpc/serialization/Complex.h"
#include "rec/rpc/serialization/ByteArray.h"
#include "rec/rpc/serialization/String.h"

DEFINE_EMPTY_TOPICDATA( rec_robotino_rpc_display_clear )

#endif //_REC_ROBOTINO_RPC_DISPLAY_CLEAR_H_
