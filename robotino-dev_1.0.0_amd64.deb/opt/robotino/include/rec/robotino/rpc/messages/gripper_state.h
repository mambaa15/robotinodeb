#ifndef _REC_ROBOTINO_RPC_GRIPPER_STATE_H_
#define _REC_ROBOTINO_RPC_GRIPPER_STATE_H_

#include "rec/rpc/serialization/Primitive.h"

DEFINE_PRIMITIVE_TOPICDATA( rec_robotino_rpc_gripper_state, int )


#endif //_REC_ROBOTINO_RPC_GRIPPER_STATE_H_
