#ifndef _REC_ROBOTINO_RPC_GRAPPLER_TOGGLE_TORQUE_H_
#define _REC_ROBOTINO_RPC_GRAPPLER_TOGGLE_TORQUE_H_

#include "rec/rpc/serialization/Serializable.h"

DEFINE_EMPTY_TOPICDATA( rec_robotino_rpc_grappler_toggle_torque )

#endif //_REC_ROBOTINO_RPC_GRAPPLER_TOGGLE_TORQUE_H_
