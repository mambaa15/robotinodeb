#ifndef _REC_ROBOTINO_RPC_REQUEST_SHUTDOWN_H_
#define _REC_ROBOTINO_RPC_REQUEST_SHUTDOWN_H_

#include "rec/rpc/serialization/Primitive.h"

DEFINE_PRIMITIVE_TOPICDATA( rec_robotino_rpc_request_shutdown, bool )


#endif //_REC_ROBOTINO_RPC_REQUEST_SHUTDOWN_H_
