#!/bin/bash

cd /root

apt-get update
apt-get download robotino3-firmware
apt-get download robotino4-firmware