#!/bin/bash

function usage {
  echo reconfigure_wlan0 master ssid cipher psk
  echo reconfigure_wlan0 client dhcp ssid psk
  echo reconfigure_wlan0 client static address netmask gateway dns ssid psk
  echo cipher: CCMP or TKIP
  echo netmask 24/16/8
}
echo "run reconfigure_wlan0.sh with parameters:"
echo $@

if [ $# -ne 4 ] && [ $# -ne 4 ] && [ $# -ne 8 ] ; then
  echo "Wrong number of arguments $#"
  usage
  exit 1
fi

NM_CONF_FILE="/etc/NetworkManager/system-connections/wlan0"
rm -f "$NM_CONF_FILE"

echo -n "nmcli con down wlan0 ... "
nmcli con down wlan0
if [ 0 -eq $? ] ; then
  echo "Success"
else
  echo "Failed"
  echo -n "ifdown wlan0 ... "
  ifdown wlan0
  if [ 0 -eq $? ] ; then
    echo "Success"
  else
    echo "Failed"
  fi
fi

if [ $# -eq 4 ] ; then
  
  if [ $1 == "master" ] ; then
	SSID=$2
	CIPHER=$3
	CIPHER=${CIPHER//\// }
	PSK=$4
	echo mod_hostap.pl "$SSID" "$CIPHER" "$PSK" 
	/opt/robotino/scripts/mod_hostap.pl "$SSID" "$CIPHER" "$PSK" 
	echo set_network_static.pl wlan0 172.26.1.1 255.255.0.0 master
	/opt/robotino/scripts/set_network_static.pl wlan0 172.26.1.1 255.255.0.0 master
	  
	nmcli con reload
	  
	ifup wlan0
	exit 0
  else
	if [ $2 != "dhcp" ] ; then
		echo Parameter 2 should be dhcp
		usage
		exit 1
	fi

	SSID=$3
	PSK=$4

	echo "clear wlan0 section in /etc/network/interface"
	/opt/robotino/scripts/set_network_static.pl wlan0 172.26.1.1 255.255.0.0 client
  
  cat << EOF > "$NM_CONF_FILE"
[connection]
id=wlan0
uuid=4a2010db-68c5-4ef6-8013-27d22186dc56
type=wifi
permissions=
secondaries=

[wifi]
mac-address=
mac-address-blacklist=
mac-address-randomization=0
mode=infrastructure
seen-bssids=
ssid=$SSID

[wifi-security]
auth-alg=open
group=
key-mgmt=wpa-psk
pairwise=
proto=
psk=$PSK

[ipv4]
dns-search=
method=auto

[ipv6]
addr-gen-mode=stable-privacy
dns-search=
method=auto
EOF

  fi

elif [ $# -eq 8 ] ; then

  if [ $1 != "client" ] ; then
    echo Parameter 1 should be master
    usage
    exit 1
  fi

  if [ $2 != "static" ] ; then
    echo Parameter 2 should be static
    usage
    exit 1
  fi

  ADDRESS=$3
  NETMASK=$4
  GATEWAY=$5
  DNS=$6
  SSID=$7
  PSK=$8

  echo "clear wlan0 section in /etc/network/interface"
  /opt/robotino/scripts/set_network_static.pl wlan0 172.26.1.1 255.255.0.0 client
  
  cat << EOF > "$NM_CONF_FILE"
[connection]
id=wlan0
uuid=4a2010db-68c5-4ef6-8013-27d22186dc56
type=wifi
permissions=
secondaries=

[wifi]
mac-address=
mac-address-blacklist=
mac-address-randomization=0
mode=infrastructure
seen-bssids=
ssid=$SSID

[wifi-security]
auth-alg=open
group=
key-mgmt=wpa-psk
pairwise=
proto=
psk=$PSK

[ipv4]
address1=$ADDRESS/$NETMASK,$GATEWAY
dns=$DNS
dns-search=
method=auto

[ipv6]
addr-gen-mode=stable-privacy
dns-search=
method=auto
EOF

fi

chmod 600 "$NM_CONF_FILE"

nmcli con reload
nmcli con up wlan0


