#!/bin/bash

PKG=$1

SERVICES=`dpkg -L $1 | grep /etc/systemd/system/`
if [ 0 -eq $? ]; then
	for i in $SERVICES
	do
		i=${i##*/}
		echo ${i%.*}
	done
	exit 0
else
	exit 1
fi