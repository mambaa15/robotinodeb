#!/bin/bash

systemctl --no-legend --no-pager --all --type=service