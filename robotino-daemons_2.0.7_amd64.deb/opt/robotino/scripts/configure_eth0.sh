#!/bin/bash

eth0_method=$1
eth0_address=$2
eth0_netmask=$3
eth0_gateway=$4
eth0_dns=$5

eth0_1_enabled=$6
eth0_1_address=$7
eth0_1_netmask=$8
eth0_1_gateway=$9

eth0_2_enabled=$10
eth0_2_address=$11
eth0_2_netmask=$12
eth0_2_gateway=$13

function usage
{
  echo configure_eth0.sh eth0_method eth0_address eth0_netmask eth0_gateway eth0_dns eth0_1_enabled eth0_1_address eth0_1_netmask eth0_1_gateway eth0_2_enabled eth0_2_address eth0_2_netmask eth0_2_gateway
  echo eth0_method=auto/manual
  echo eth0_netmask=0 to 32
  echo eth0_1_enabled=yes/no
  echo eth0_1_netmask=0 to 32
  echo eth0_2_enabled=yes/no
  echo eth_2_netmask=0 to 32
}

if [ $# -ne 13 ] ; then
  usage
  echo ""
  echo Failure
  exit 1
fi

TEMP_FILE="/tmp/__eth0_nmconfig__"
rm -f "$TEMP_FILE"

cat << EOF > "$TEMP_FILE"
[connection]
id=eth0
uuid=03d1fb6f-efcf-3f57-85e1-85b9cdb9ab9d
type=ethernet
autoconnect-priority=-999
interface-name=eth0
permissions=
secondaries=
timestamp=1547803650

[ethernet]
duplex=full
mac-address=
mac-address-blacklist=

[ipv6]
addr-gen-mode=stable-privacy
dns-search=
ip6-privacy=0
method=auto

[ipv4]
EOF

if [ "auto" == $eth0_method ]; then
  echo "eth0_method=auto"
  echo "method=auto" >> "$TEMP_FILE"
elif [ "manual" == $eth0_method ]; then
  echo "eth0_method=manual"
  echo "address1=$eth0_address/$eth0_netmask,$eth0_gateway"
  echo "method=manual" >> "$TEMP_FILE"
  echo "address1=$eth0_address/$eth0_netmask,$eth0_gateway" >> "$TEMP_FILE"
else
  echo eth0_method=error
  exit 1
fi

echo "dns=$eth0_dns"
echo "dns=$eth0_dns" >> "$TEMP_FILE"

if [ "yes" == $eth0_1_enabled ]; then
  echo "address2=$eth0_1_address/$eth0_1_netmask,$eth0_1_gateway"
  echo "address2=$eth0_1_address/$eth0_1_netmask,$eth0_1_gateway" >> "$TEMP_FILE"
fi

if [ "yes" == $eth0_2_enabled ]; then
  echo "address3=$eth0_2_address/$eth0_2_netmask,$eth0_2_gateway"
  echo "address3=$eth0_2_address/$eth0_2_netmask,$eth0_2_gateway" >> "$TEMP_FILE"
fi

cat << EOF >> "$TEMP_FILE"
dns-search=
EOF

NM_CONF_FILE="/etc/NetworkManager/system-connections/eth0"
rm -f "$NM_CONF_FILE"

mv "$TEMP_FILE" "$NM_CONF_FILE"

chmod 600 "$NM_CONF_FILE"

nmcli con reload
nmcli con up eth0

echo ""
nmcli connection show eth0 | grep IP4.ADDRESS