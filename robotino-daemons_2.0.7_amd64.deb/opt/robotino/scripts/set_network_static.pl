#!/usr/bin/perl

# return values:
# 0: OK
# 1: Wrong number of parameters
# 2: Template does not exist or /etc/network/interfaces not availables for writing
# 3: IP-Address not in correct format
# 4: Netmask not in correct format
# 5: failure reconfiguring address

if( $#ARGV < 2 )
{
  print "Usage: set_network_static.pl interface address netmask [mode]\n";
  print "mode: client|server\n";
  exit( 1 );
}

if( $#ARGV > 3 )
{
  print "Usage: set_network_static.pl interface address netmask [mode]\n";
  print "mode: client|server\n";
  exit( 1 );
}

my $iface = @ARGV[0];
my $ip = @ARGV[1];
my $netmask = @ARGV[2];
my $mode;

if( 3 == $#ARGV )
{
	$mode =  @ARGV[3];
}

print "mode=$mode\n";

if( $ip !~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/ )
{
  print "invalid ip : $ip\n";
  exit( 3 );
}

if( $netmask !~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/ )
{
  print "invalid netmask : $netmask\n";
  exit( 4 );
}

my $cfg = "/etc/network/interfaces";

open( IFBACKUP, "<$cfg" ) or exit( 2 );

my $save = '';
while( <IFBACKUP> )
{
  $save .= $_;
}
close( IFBACKUP );

my @lines = split /\n/, $save;

open( IF, ">$cfg" ) or exit( 2 );

my $section = 'start';
my $found = 0;
my $nlcount=0;

sub printConfig
{
	if( $mode eq "master" )
	{
		if( 0 == $found )
		{
			print IF "\n\n";
		}
		print IF "iface $iface inet static\n";
		print IF "  address $ip\n";
		print IF "  netmask $netmask";
		print IF "\n  up service hostapd start";
		print IF "\n  up service isc-dhcp-server start";
		print IF "\n  down service hostapd stop";
		print IF "\n  down service isc-dhcp-server stop";
	}
	elsif( $mode eq "" )
	{
		print IF "iface $iface inet static\n";
		print IF "  address $ip\n";
		print IF "  netmask $netmask";
	}
}

foreach my $line (@lines)
{
  if( $section eq "start" )
  {
    $section = '';
  }
  elsif( $nlcount <= 0 )
  {
    print IF "\n";
    $nlcount = 1;
  }
   
  if( $line =~ /iface $iface inet/ )
  {
    $found = 1;
	printConfig();
    $nlcount--;
    $section = "xxx";
    next;
  }
  elsif( $line =~ /auto/ )
  {
    $section = '';
  }
  elsif( $line =~ /iface/ )
  {
    $section = '';
  }
  
  if( $section eq "xxx" )
  {
    if( $line =~ /address/ )
    {
      next;
    }
    if( $line =~ /netmask/ )
    {
      next;
    }
	if( $line =~ /up / )
    {
      next;
    }
	if( $line =~ /down / )
    {
      next;
    }
	if( $line =~ /wpa-conf / )
    {
      next;
    }
  }
  
  print IF "$line";
  $nlcount--;
}

if( 0 == $found )
{
  printConfig();
}

close( IF );

system( "sync" );
exit( 0 );

